package com.filmfinder.websocket;

import java.util.ArrayList;

public class Data {
    public static final int JOINGAME = 1;
    public static final int GETNICK = 2;
    public static final int ADDSELECT = 3;
    public static final int USERUPDATED = 4;
    public static final int PUSHGAME = 5;
    public static final int VOTE = 6;
    public static final int RESULTS = 7;
    public static final int PLAYERS = 8;

    // private int command;
    // private int gameId;
    // private int selectedMovie = -1;
    // private String nickname;
    // private ArrayList<Integer> votes;

    // public int getCommand() {
    //     return this.command;
    // }

    // public void setCommand(int command) {
    //     this.command = command;
    // }

    // public int getGameId() {
    //     return this.gameId;
    // }

    // public void setGameId(int gameId) {
    //     this.gameId = gameId;
    // }

    // public int getSelectedMovie() {
    //     return this.selectedMovie;
    // }

    // public void setSelectedMovie(int selectedMovie) {
    //     this.selectedMovie = selectedMovie;
    // }

    // public String getNickname() {
    //     return this.nickname;
    // }

    // public void setNickname(String nickname) {
    //     this.nickname = nickname;
    // }

    // public ArrayList<Integer> getVotes() {
    //     return this.votes;
    // }

    // public void setVotes(ArrayList<Integer> votes) {
    //     this.votes = votes;
    // }

}
