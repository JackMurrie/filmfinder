USE film_finder;

-- INSERT INTO user (name, email, credential)
-- VALUES
--     ('Kristian', 'kristian.fiebig@gmail.com', 'asdfgh'),
--     ('Hikari', 'hikari@gmail.com', 'asdfgh'),
--     ('Hai Long Bi', 'hdsdjcndfjs@gmail.com', 'asdfgh'),
--     ('Jack Murrie', 'jack@gmail.com', 'asdfgh'),
--     ('Quoc-An Li', 'quock@gmail.com', 'asdfgh'),
--     ('Jake', 'jake@gmail.com', 'asdfgh');

-- INSERT INTO follower (followed_id, follower_id)
-- Values
--     (1,2),
--     (1,3),
--     (1, 6),
--     (2, 1),
--     (2, 3);

-- INSERT IGNORE INTO genre Values
--     ('Action'),
--     ('Adventure'),
--     ('Animation'),
--     ('Comedy'),
--     ('Crime'),
--     ('Documentary'),
--     ('Drama'),
--     ('Family'),
--     ('Fantasy'),
--     ('History'),
--     ('Horror'),
--     ('Music'),
--     ('Mystery'),
--     ('Romance'),
--     ('Science Fiction'),
--     ('TV Movie'),
--     ('Thriller'),
--     ('War'),
--     ('Western');